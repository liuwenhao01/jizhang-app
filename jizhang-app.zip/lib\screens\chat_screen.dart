import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/transaction.dart';
import '../database/database_helper.dart';
import '../services/message_parser.dart';
import 'statistics_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [];
  final ScrollController _scrollController = ScrollController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadRecentTransactions();
    _addWelcomeMessage();
  }

  void _addWelcomeMessage() {
    setState(() {
      _messages.add(ChatMessage(
        text: '你好！我是你的记账助手 😊\n\n直接说出你的消费就能记账，比如：\n• "早餐花了15块"\n• "微信买咖啡20元"\n• "收到工资5000"\n\n开始聊天记账吧！',
        isBot: true,
        timestamp: DateTime.now(),
      ));
    });
  }

  Future<void> _loadRecentTransactions() async {
    try {
      final transactions = await DatabaseHelper.instance.getAllTransactions();
      final recentTransactions = transactions.take(5).toList();
      
      if (recentTransactions.isNotEmpty) {
        setState(() {
          _messages.add(ChatMessage(
            text: '最近的记录：',
            isBot: true,
            timestamp: DateTime.now(),
            transactions: recentTransactions,
          ));
        });
      }
    } catch (e) {
      print('加载交易记录出错: $e');
    }
  }

  void _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;

    final userMessage = _messageController.text.trim();
    _messageController.clear();

    // 添加用户消息
    setState(() {
      _messages.add(ChatMessage(
        text: userMessage,
        isBot: false,
        timestamp: DateTime.now(),
      ));
      _isLoading = true;
    });

    _scrollToBottom();

    // 解析消息并尝试创建交易记录
    try {
      final transaction = MessageParser.parseMessage(userMessage);
      
      if (transaction != null) {
        // 保存交易记录
        await DatabaseHelper.instance.createTransaction(transaction);
        
        // 生成机器人回复
        final suggestions = MessageParser.generateReplySuggestions(userMessage);
        final botReply = suggestions.isNotEmpty ? suggestions.first : '记录完成！';
        
        setState(() {
          _messages.add(ChatMessage(
            text: botReply,
            isBot: true,
            timestamp: DateTime.now(),
            transaction: transaction,
          ));
          _isLoading = false;
        });
      } else {
        // 无法解析为交易记录
        setState(() {
          _messages.add(ChatMessage(
            text: '抱歉，我没有理解你的意思 😅\n\n请尝试这样说：\n• "午餐花了30块"\n• "微信支付咖啡25元"\n• "收到红包100"\n\n或者输入"帮助"查看更多示例',
            isBot: true,
            timestamp: DateTime.now(),
          ));
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _messages.add(ChatMessage(
          text: '记录时出现错误，请稍后再试 😔',
          isBot: true,
          timestamp: DateTime.now(),
        ));
        _isLoading = false;
      });
    }

    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('记账助手'),
        actions: [
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const StatisticsScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return _buildMessageBubble(_messages[index]);
              },
            ),
          ),
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: CircularProgressIndicator(),
            ),
          _buildInputArea(),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: message.isBot 
            ? MainAxisAlignment.start 
            : MainAxisAlignment.end,
        children: [
          if (message.isBot) ...[
            const CircleAvatar(
              backgroundColor: Color(0xFF07C160),
              child: Icon(Icons.smart_toy, color: Colors.white),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: message.isBot 
                    ? Colors.white 
                    : const Color(0xFF07C160),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.text,
                    style: TextStyle(
                      color: message.isBot ? Colors.black87 : Colors.white,
                      fontSize: 16,
                    ),
                  ),
                  if (message.transaction != null)
                    _buildTransactionCard(message.transaction!),
                  if (message.transactions != null)
                    ...message.transactions!.map(_buildTransactionCard),
                  const SizedBox(height: 4),
                  Text(
                    DateFormat('HH:mm').format(message.timestamp),
                    style: TextStyle(
                      color: message.isBot 
                          ? Colors.grey[600] 
                          : Colors.white70,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!message.isBot) ...[
            const SizedBox(width: 8),
            const CircleAvatar(
              backgroundColor: Color(0xFF07C160),
              child: Icon(Icons.person, color: Colors.white),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTransactionCard(Transaction transaction) {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: transaction.type == 'income' 
            ? Colors.green[50] 
            : Colors.red[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: transaction.type == 'income' 
              ? Colors.green[200]! 
              : Colors.red[200]!,
        ),
      ),
      child: Row(
        children: [
          Text(
            transaction.categoryIcon,
            style: const TextStyle(fontSize: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction.description,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                Text(
                  '${transaction.category} • ${transaction.paymentMethod ?? ''}',
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${transaction.type == 'income' ? '+' : '-'}¥${transaction.amount.toStringAsFixed(2)}',
            style: TextStyle(
              color: transaction.type == 'income' 
                  ? Colors.green[700] 
                  : Colors.red[700],
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              decoration: InputDecoration(
                hintText: '说说你的消费...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[100],
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
              ),
              onSubmitted: (_) => _sendMessage(),
            ),
          ),
          const SizedBox(width: 8),
          FloatingActionButton(
            mini: true,
            onPressed: _sendMessage,
            backgroundColor: const Color(0xFF07C160),
            child: const Icon(Icons.send, color: Colors.white),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }
}

class ChatMessage {
  final String text;
  final bool isBot;
  final DateTime timestamp;
  final Transaction? transaction;
  final List<Transaction>? transactions;

  ChatMessage({
    required this.text,
    required this.isBot,
    required this.timestamp,
    this.transaction,
    this.transactions,
  });
}
