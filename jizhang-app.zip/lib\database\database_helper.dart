import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/transaction.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('jizhang.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const textType = 'TEXT NOT NULL';
    const realType = 'REAL NOT NULL';
    const textTypeNullable = 'TEXT';

    await db.execute('''
      CREATE TABLE transactions (
        id $idType,
        amount $realType,
        category $textType,
        description $textType,
        date $textType,
        type $textType,
        location $textTypeNullable,
        paymentMethod $textTypeNullable
      )
    ''');

    // 插入一些示例数据
    await _insertSampleData(db);
  }

  Future _insertSampleData(Database db) async {
    final sampleTransactions = [
      {
        'amount': 15.5,
        'category': '餐饮',
        'description': '早餐',
        'date': DateTime.now().subtract(const Duration(days: 1)).toIso8601String(),
        'type': 'expense',
        'location': '公司楼下',
        'paymentMethod': '微信',
      },
      {
        'amount': 5000.0,
        'category': '工资',
        'description': '月薪',
        'date': DateTime.now().subtract(const Duration(days: 5)).toIso8601String(),
        'type': 'income',
        'paymentMethod': '银行卡',
      },
    ];

    for (var transaction in sampleTransactions) {
      await db.insert('transactions', transaction);
    }
  }

  // 创建交易记录
  Future<Transaction> createTransaction(Transaction transaction) async {
    final db = await instance.database;
    final id = await db.insert('transactions', transaction.toMap());
    return transaction.copyWith(id: id);
  }

  // 获取所有交易记录
  Future<List<Transaction>> getAllTransactions() async {
    final db = await instance.database;
    const orderBy = 'date DESC';
    final result = await db.query('transactions', orderBy: orderBy);
    return result.map((json) => Transaction.fromMap(json)).toList();
  }

  // 根据日期范围获取交易记录
  Future<List<Transaction>> getTransactionsByDateRange(
      DateTime startDate, DateTime endDate) async {
    final db = await instance.database;
    final result = await db.query(
      'transactions',
      where: 'date BETWEEN ? AND ?',
      whereArgs: [startDate.toIso8601String(), endDate.toIso8601String()],
      orderBy: 'date DESC',
    );
    return result.map((json) => Transaction.fromMap(json)).toList();
  }

  // 获取统计数据
  Future<Map<String, double>> getStatistics() async {
    final db = await instance.database;
    
    final incomeResult = await db.rawQuery(
      'SELECT SUM(amount) as total FROM transactions WHERE type = ?',
      ['income']
    );
    
    final expenseResult = await db.rawQuery(
      'SELECT SUM(amount) as total FROM transactions WHERE type = ?',
      ['expense']
    );

    final totalIncome = incomeResult.first['total'] as double? ?? 0.0;
    final totalExpense = expenseResult.first['total'] as double? ?? 0.0;

    return {
      'income': totalIncome,
      'expense': totalExpense,
      'balance': totalIncome - totalExpense,
    };
  }

  // 根据分类获取统计
  Future<Map<String, double>> getCategoryStatistics() async {
    final db = await instance.database;
    final result = await db.rawQuery('''
      SELECT category, SUM(amount) as total 
      FROM transactions 
      WHERE type = 'expense'
      GROUP BY category 
      ORDER BY total DESC
    ''');

    Map<String, double> categoryStats = {};
    for (var row in result) {
      categoryStats[row['category'] as String] = row['total'] as double;
    }
    return categoryStats;
  }

  // 删除交易记录
  Future<int> deleteTransaction(int id) async {
    final db = await instance.database;
    return await db.delete(
      'transactions',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // 关闭数据库
  Future close() async {
    final db = await instance.database;
    db.close();
  }
}

extension TransactionExtension on Transaction {
  Transaction copyWith({
    int? id,
    double? amount,
    String? category,
    String? description,
    DateTime? date,
    String? type,
    String? location,
    String? paymentMethod,
  }) {
    return Transaction(
      id: id ?? this.id,
      amount: amount ?? this.amount,
      category: category ?? this.category,
      description: description ?? this.description,
      date: date ?? this.date,
      type: type ?? this.type,
      location: location ?? this.location,
      paymentMethod: paymentMethod ?? this.paymentMethod,
    );
  }
}
