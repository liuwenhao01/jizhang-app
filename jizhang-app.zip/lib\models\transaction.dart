class Transaction {
  final int? id;
  final double amount;
  final String category;
  final String description;
  final DateTime date;
  final String type; // 'income' 收入 或 'expense' 支出
  final String? location; // 消费地点
  final String? paymentMethod; // 支付方式：现金、微信、支付宝、银行卡等

  Transaction({
    this.id,
    required this.amount,
    required this.category,
    required this.description,
    required this.date,
    required this.type,
    this.location,
    this.paymentMethod,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'amount': amount,
      'category': category,
      'description': description,
      'date': date.toIso8601String(),
      'type': type,
      'location': location,
      'paymentMethod': paymentMethod,
    };
  }

  factory Transaction.fromMap(Map<String, dynamic> map) {
    return Transaction(
      id: map['id'],
      amount: map['amount']?.toDouble() ?? 0.0,
      category: map['category'] ?? '',
      description: map['description'] ?? '',
      date: DateTime.parse(map['date']),
      type: map['type'] ?? 'expense',
      location: map['location'],
      paymentMethod: map['paymentMethod'],
    );
  }

  // 获取分类的显示图标
  String get categoryIcon {
    switch (category) {
      case '餐饮':
        return '🍽️';
      case '交通':
        return '🚗';
      case '购物':
        return '🛒';
      case '娱乐':
        return '🎮';
      case '医疗':
        return '🏥';
      case '教育':
        return '📚';
      case '住房':
        return '🏠';
      case '工资':
        return '💰';
      case '投资':
        return '📈';
      case '红包':
        return '🧧';
      default:
        return type == 'income' ? '💰' : '💳';
    }
  }

  // 获取支付方式图标
  String get paymentIcon {
    switch (paymentMethod) {
      case '微信':
        return '💚';
      case '支付宝':
        return '💙';
      case '现金':
        return '💵';
      case '银行卡':
        return '💳';
      default:
        return '💳';
    }
  }
}
