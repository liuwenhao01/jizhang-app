// 复制这段代码到 https://dartpad.dev 体验记账功能
import 'dart:math';

void main() {
  print('=== 记账助手演示 ===');
  
  // 创建记账助手
  var assistant = AccountingAssistant();
  
  // 测试记账功能
  List<String> testMessages = [
    '早餐花了15块',
    '微信买咖啡25元',
    '收到工资5000',
    '打车30元',
    '超市购物150'
  ];
  
  print('\n📱 聊天记账演示：\n');
  
  for (String message in testMessages) {
    print('👤 您：$message');
    var result = assistant.parseMessage(message);
    print('🤖 助手：${result['reply']}');
    print('   记录：${result['record']}');
    print('');
  }
  
  // 显示统计
  print('📊 统计信息：');
  assistant.showStatistics();
}

class AccountingAssistant {
  List<Map<String, dynamic>> records = [];
  
  Map<String, String> parseMessage(String message) {
    // 提取金额
    RegExp amountRegex = RegExp(r'(\d+\.?\d*)');
    var match = amountRegex.firstMatch(message);
    double amount = match != null ? double.parse(match.group(1)!) : 0;
    
    // 判断类型
    String type = message.contains('收到') || message.contains('工资') ? '收入' : '支出';
    
    // 判断分类
    String category = '其他';
    if (message.contains('早餐') || message.contains('午餐') || message.contains('咖啡')) {
      category = '餐饮';
    } else if (message.contains('打车') || message.contains('车')) {
      category = '交通';
    } else if (message.contains('买') || message.contains('购物') || message.contains('超市')) {
      category = '购物';
    } else if (message.contains('工资')) {
      category = '工资';
    }
    
    // 判断支付方式
    String payment = '现金';
    if (message.contains('微信')) {
      payment = '微信';
    } else if (message.contains('支付宝')) {
      payment = '支付宝';
    }
    
    // 保存记录
    var record = {
      'amount': amount,
      'type': type,
      'category': category,
      'payment': payment,
      'description': message,
      'time': DateTime.now().toString().substring(0, 16)
    };
    records.add(record);
    
    // 生成回复
    List<String> replies = [
      '记录完成！💰',
      '已保存到账本 ✅',
      '记账成功 😊'
    ];
    String reply = replies[Random().nextInt(replies.length)];
    
    return {
      'reply': reply,
      'record': '$type ¥$amount ($category - $payment)'
    };
  }
  
  void showStatistics() {
    double totalIncome = 0;
    double totalExpense = 0;
    
    for (var record in records) {
      if (record['type'] == '收入') {
        totalIncome += record['amount'];
      } else {
        totalExpense += record['amount'];
      }
    }
    
    print('总收入：¥${totalIncome.toStringAsFixed(2)}');
    print('总支出：¥${totalExpense.toStringAsFixed(2)}');
    print('余额：¥${(totalIncome - totalExpense).toStringAsFixed(2)}');
    print('记录条数：${records.length}');
  }
}
