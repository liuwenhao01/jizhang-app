package com.jizhang.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
