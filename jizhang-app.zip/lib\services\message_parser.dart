import '../models/transaction.dart';

class MessageParser {
  // 预定义的分类关键词
  static const Map<String, List<String>> categoryKeywords = {
    '餐饮': ['吃', '早餐', '午餐', '晚餐', '夜宵', '喝', '咖啡', '奶茶', '餐厅', '外卖', '食', '饭', '面', '粥'],
    '交通': ['打车', '地铁', '公交', '出租车', '滴滴', 'uber', '油费', '停车', '过路费', '车票', '机票', '高铁'],
    '购物': ['买', '购', '商场', '超市', '淘宝', '京东', '拼多多', '衣服', '鞋子', '化妆品', '包包'],
    '娱乐': ['电影', '游戏', 'ktv', '酒吧', '旅游', '景点', '门票', '唱歌', '娱乐'],
    '医疗': ['医院', '药', '看病', '体检', '医疗', '挂号费', '药费'],
    '教育': ['书', '学费', '培训', '课程', '教育', '学习'],
    '住房': ['房租', '水费', '电费', '燃气费', '物业费', '房贷', '装修'],
    '工资': ['工资', '薪水', '奖金', '提成'],
    '投资': ['理财', '股票', '基金', '投资', '分红'],
    '红包': ['红包', '转账', '收到'],
  };

  // 支付方式关键词
  static const Map<String, List<String>> paymentKeywords = {
    '微信': ['微信', 'wx', '微信支付'],
    '支付宝': ['支付宝', 'zfb', 'alipay'],
    '现金': ['现金', '现钞', '纸币'],
    '银行卡': ['银行卡', '刷卡', '信用卡', '储蓄卡'],
  };

  // 解析消息并创建交易记录
  static Transaction? parseMessage(String message) {
    if (message.trim().isEmpty) return null;

    // 提取金额
    double? amount = _extractAmount(message);
    if (amount == null) return null;

    // 判断收入或支出
    String type = _determineType(message);

    // 提取分类
    String category = _extractCategory(message, type);

    // 提取支付方式
    String? paymentMethod = _extractPaymentMethod(message);

    // 提取描述
    String description = _extractDescription(message, amount, category, paymentMethod);

    return Transaction(
      amount: amount,
      category: category,
      description: description,
      date: DateTime.now(),
      type: type,
      paymentMethod: paymentMethod,
    );
  }

  // 提取金额
  static double? _extractAmount(String message) {
    // 匹配数字模式：12.5, 12, .5等
    final amountRegex = RegExp(r'(\d+\.?\d*|\.\d+)');
    final match = amountRegex.firstMatch(message);
    
    if (match != null) {
      return double.tryParse(match.group(1)!);
    }
    return null;
  }

  // 判断收入还是支出
  static String _determineType(String message) {
    const incomeKeywords = ['收到', '工资', '奖金', '红包', '转账', '收入', '赚', '提成', '分红'];
    const expenseKeywords = ['花', '买', '付', '支出', '消费', '花费'];

    String lowerMessage = message.toLowerCase();
    
    for (String keyword in incomeKeywords) {
      if (lowerMessage.contains(keyword)) {
        return 'income';
      }
    }
    
    for (String keyword in expenseKeywords) {
      if (lowerMessage.contains(keyword)) {
        return 'expense';
      }
    }
    
    // 默认为支出
    return 'expense';
  }

  // 提取分类
  static String _extractCategory(String message, String type) {
    String lowerMessage = message.toLowerCase();
    
    if (type == 'income') {
      // 收入分类
      for (String category in ['工资', '投资', '红包']) {
        if (categoryKeywords[category] != null) {
          for (String keyword in categoryKeywords[category]!) {
            if (lowerMessage.contains(keyword)) {
              return category;
            }
          }
        }
      }
      return '其他收入';
    } else {
      // 支出分类
      for (String category in categoryKeywords.keys) {
        if (category == '工资' || category == '投资' || category == '红包') continue;
        
        for (String keyword in categoryKeywords[category]!) {
          if (lowerMessage.contains(keyword)) {
            return category;
          }
        }
      }
      return '其他支出';
    }
  }

  // 提取支付方式
  static String? _extractPaymentMethod(String message) {
    String lowerMessage = message.toLowerCase();
    
    for (String method in paymentKeywords.keys) {
      for (String keyword in paymentKeywords[method]!) {
        if (lowerMessage.contains(keyword)) {
          return method;
        }
      }
    }
    return null;
  }

  // 提取描述
  static String _extractDescription(String message, double amount, String category, String? paymentMethod) {
    String description = message.trim();
    
    // 移除金额
    description = description.replaceAll(RegExp(r'\d+\.?\d*'), '').trim();
    
    // 移除常见的无用词汇
    const removeWords = ['元', '块', '花了', '买了', '吃了', '用了', '支付', '付款'];
    for (String word in removeWords) {
      description = description.replaceAll(word, '').trim();
    }
    
    // 如果描述为空，使用分类作为描述
    if (description.isEmpty || description.length < 2) {
      description = category;
    }
    
    return description;
  }

  // 生成智能回复建议
  static List<String> generateReplySuggestions(String lastMessage) {
    if (lastMessage.contains('吃') || lastMessage.contains('餐')) {
      return ['记录完成！今天吃得真不错 😊', '已记账，要控制饮食预算哦', '记录成功，记得多喝水'];
    } else if (lastMessage.contains('买') || lastMessage.contains('购')) {
      return ['购物记录已保存 🛒', '又买买买了呀，已记录', '消费已记录，理性购物哦'];
    } else if (lastMessage.contains('工资') || lastMessage.contains('收入')) {
      return ['收入记录成功！💰', '恭喜发财，已记录收入', '钱包又厚了，已保存'];
    } else {
      return ['记录完成！', '已成功记账', '保存成功 ✅'];
    }
  }
}
